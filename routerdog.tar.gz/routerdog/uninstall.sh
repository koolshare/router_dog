#!/bin/sh
source /koolshare/scripts/base.sh

rm -rf /koolshare/bin/routerdog
rm -rf /koolshare/bin/routerdog*
rm -rf /koolshare/bin/scripts
rm -rf /koolshare/res/icon-routerdog.png
rm -rf /koolshare/scripts/routerdog*
rm -rf /koolshare/webs/Module_routerdog.asp
rm -rf /tmp/routerdog*

